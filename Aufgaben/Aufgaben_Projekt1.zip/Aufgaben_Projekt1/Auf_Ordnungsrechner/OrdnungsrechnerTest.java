import static org.junit.Assert.*;

import org.junit.Test;

public class OrdnungsrechnerTest {

	@Test
	public void richtigeOrdnung() {
		int expected = 4;
		assertTrue(expected == Ordnungsrechner.bstOrdnung(5,13));
	}

	@Test
	public void richtigeOrdnungNegativ() {
		int expected = 10;
		assertEquals(expected, Ordnungsrechner.bstOrdnung(-3,11));
	}
	
}
