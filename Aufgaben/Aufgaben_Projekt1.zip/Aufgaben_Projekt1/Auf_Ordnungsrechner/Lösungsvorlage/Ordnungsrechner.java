public class Ordnungsrechner {
	// main-Methode und bstOrdnung-Methode implementieren
}
