#!/bin/bash
set -e

echo Compile ...
javac -cp .:junit-4.12.jar:hamcrest-core-1.3.jar Ordnungsrechner*.java
javac -cp .:junit-4.12.jar OrdnungsrechnerTest.java
echo Testing ...
java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore OrdnungsrechnerTest | grep -v at
