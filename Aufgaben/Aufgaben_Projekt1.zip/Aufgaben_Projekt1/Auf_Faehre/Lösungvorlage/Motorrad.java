import java.util.ArrayList;

public class Motorrad extends Fahrzeug {
	// Wie PKW!
}
	
