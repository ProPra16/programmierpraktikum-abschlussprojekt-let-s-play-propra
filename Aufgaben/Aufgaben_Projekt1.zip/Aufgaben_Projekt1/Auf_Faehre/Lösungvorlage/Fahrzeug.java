public abstract class Fahrzeug {
	// Konstruktor und Methoden (z.B. berechnegewicht...)
	// Gegebene Methoden sind testrelevant, Namen nicht �ndern
	protected Fahrzeug(Person fahrer, double breite,
			double laenge, double gewicht){
		
	}
	
	public double berechneFlaeche(){
		
	}
}
