public class Fahrrad extends Fahrzeug {

}
