public class Person {
	// Eigenschaften und Methoden von Personen implementieren
	// Gegebene Methoden sind testrelevant, Namen nicht �ndern
	public Person(double gewicht){
	}
}