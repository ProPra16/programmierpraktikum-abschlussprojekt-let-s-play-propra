import java.util.ArrayList;

public class Pkw extends Fahrzeug {
	// Gegebene Methoden sind testrelevant, Namen nicht �ndern
	// angesprochene ArrayList für Beifahrer?

	// Konstruktor und Methode zur Gewichtsbestimmung (Achtung: Override der Gewichtsberechnung der Oberklasse!)
	public Pkw(Person fahrer, double breite, double laenge, double gewicht){
	}

	@Override
	public void berechneGewicht(){
		// Gewicht der Insassen zum Fahrzeuggewicht addieren
	}
	
	public void setBeifahrer(double gewicht){
		// neuen Beifahrer dem Fahrzeug zufügen
	}
}
