public class FaehreUI {

	public static void main (String[] args){
		// Neue Fähre erstellen, Simulation des Aufladens implementieren (Fahrzeuge erstellen mit jeweiligen Insassen etc. und verladen, Ausgabe nach Beenden des Ladevorgangs
	}
	
	public static double zufallszahl(double min, double max){
		// gerundete Zufallszahl
		double zufall = Math.random() * (max - min) + min;

		zufall = zufall * 10;
		zufall = Math.round(zufall);
		zufall = zufall / 10;
		
		return zufall;
	}
}
