import java.util.ArrayList;

public class Faehre {
 /* Eigenschaften u. Methoden teilweise vorgegeben f�r Tests
	private double maxNutzGewicht = 0.0;
	private double maxNutzFlaeche = 0.0;
	private double restFlaeche = 0.0;
	private double restGewicht = 0.0;

	public Faehre(double maxNutzGewicht, double maxNutzFlaeche){
		// Konstruktor schreiben
	}
	
	public int aufladen (Fahrzeug fahrzeug){
		ggf. benötigte Variablen: status und String typ;
		
		// Fläche des Fahrzeugs bestimmen 
		// Gewicht des Fahrzeugs bestimmen
		
		// Typ des Fahrzeuges erfragen
		
	    if (genug Platz und ausreichend restliche Traglast){
			// Aufladen!
			
			switch (typ){
				// entsprechende Anzahl erhöhen!
			}
			
			// Aufladen erfolgreich:
			status = 1;
			
		} else if (zu wenig Platz oder Gewicht oder beides){
			// status 2: zu wenig Platz
			// status 3: zu wenig restl. Traglast
			// status 4: beides zu wenig!
			
		}
		return status; */
	} 
	
	public void gibLadung(){
		// oberste Zeile der Ausgabe: Beladene Fahrzeuge:
	}
	
	public void gibRest(){
		// 2 u. 3 Zeile der Ausgabe: restliche Kapazitäten
	}
}
