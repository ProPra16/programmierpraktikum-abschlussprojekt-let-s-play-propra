#!/bin/bash
# Testskript inspiriert von den Testskripts aus Informatik 1, Duesseldorf, WS15/16
echo Kompiliere Aufgabe1.java.
javac Aufgabe1.java

echo Teste Anforderungen.
test "$(java Aufgabe1 )" != ""   && echo "
ERROR: Die Ausgabe entspricht nicht den Anforderungen. Gewuenschte Ausgabe ist leer.

"

test "$(java Aufgabe1 Programmierpraktikum SS16)" != "Programmierpraktikum
SS16"   && echo "
ERROR: Die Ausgabe entspricht nicht den Anforderungen. Gewuenschte Ausgabe:
Programmierpraktikum
SS16

"

test "$(java Aufgabe1 Hallo Hallo Hallo)" != "Hallo
Hallo
Hallo"   && echo "
ERROR: Die Ausgabe entspricht nicht den Anforderungen. Gewuenschte Ausgabe:
Hallo
Hallo
Hallo

"

echo Test beendet.
