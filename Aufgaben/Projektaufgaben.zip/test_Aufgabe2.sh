#!/bin/bash
# Testskript inspiriert von den Testskripts aus Informatik 1, Duesseldorf, WS15/16
set -e

echo Kompiliere Aufgabe2.java und Aufgabe2_Test.java.
javac -cp .:junit-4.12.jar:hamcrest-core-1.3.jar Kunde.java Aufgabe2_Test.java
echo Teste Anforderungen.
java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore Aufgabe2_Test | grep -v at
