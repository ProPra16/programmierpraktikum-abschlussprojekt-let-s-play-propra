public class Kunde{
    /* Hier Instanzvariablen implemetieren */
    
    /* Hier Konstruktor implemetieren*/
    
    /* Hier Instanzmethoden implemetieren*/
    
}
