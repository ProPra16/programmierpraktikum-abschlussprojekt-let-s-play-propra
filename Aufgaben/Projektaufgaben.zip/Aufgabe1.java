/*****************************************************
 * Eingabe: Beliebig viele Strings als Kommandozeilen-
 *          argumente.
 * Ausgabe: Jeder der Eingabestrings in einer eigenen
 *          Zeile auf der Konsole.
 *****************************************************/
public class Aufgabe1{
    public static void main (String[] args){
        /* Implementieren Sie hier ihre Loesung. */
    }
} 
