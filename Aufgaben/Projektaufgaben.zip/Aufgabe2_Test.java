import static org.junit.Assert.*;
import org.junit.*;

public class Aufgabe2_Test{
    @Test
    public void knrNullNameLeer(){
        Kunde k = new Kunde(0,"");
        assertEquals(0,k.knr());
        assertEquals("",k.name());
    }
    
    @Test
    public void knrNichtNull(){
        Kunde k0 = new Kunde(42,"");
        Kunde k1 = new Kunde(13,"Informatik, Propra");
        assertEquals(42,k0.knr());
        assertEquals("",k0.name());
        assertEquals(13,k1.knr());
        assertEquals("Informatik, Propra",k1.name());
        
    }
    
    @Test
    public void nameNichtLeer(){
        Kunde k0 = new Kunde(0,"Informatik, Propra");
        Kunde k1 = new Kunde(42,"Mustermann, Max");
        assertEquals(0,k0.knr());
        assertEquals("Informatik, Propra",k0.name());
        assertEquals(42,k1.knr());
        assertEquals("Mustermann, Max",k1.name());
    }
    
    @Test
    public void toStringTest(){
        Kunde k0 = new Kunde(0,"");
        Kunde k1 = new Kunde(0,"Informatik, Propra");
        Kunde k2 = new Kunde(42,"Mustermann, Max");
        assertEquals("Kunde: \nKnr.: 0",k0.toString());
        assertEquals("Kunde: Informatik, Propra\nKnr.: 0",k1.toString());
        assertEquals("Kunde: Mustermann, Max\nKnr.: 42",k2.toString());        
    }
}
