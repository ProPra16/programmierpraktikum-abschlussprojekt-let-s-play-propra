import java.io.*;

/**
 * Print stats of animals
 *
 */
public class AnimalStats {
    public static void main(String[]args){
    if(args.length==1) {
        String b = args[0];
        switch (b) {
            case "Spatz":
                Vogel Spatz = new Vogel(//VARIABLEN);

                break;
            case "Biene":
                
                Insekt Biene = new Insekt(//VARIABLEN);

                break;
            case "Echse":
                
                Reptil Echse = new Reptil(//VARIABLEN);

                break;
            case "Dorsch":
                
                Fisch Dorsch = new Fisch(//VARIABLEN);

                break;
            case "Hund":
                
                Saeugetier Hund = new Saeugetier(//VARIABLEN);

                break;
            default:
                System.out.println(//Fehlermeldung);
        }
    }
        else {
        System.out.println(//Fehlermeldung);
    }
    }
}
