	#!/bin/bash
	echo Compile the source ...
	javac TaschenRechner.java
	
	echo Testing ...

		test "$(java TaschenRechner 4 mult 2)" != "Ergebnis: 8.0" && echo "ERROR: Found a wrong output"
test "$(java TaschenRechner -7 div 2)" != "Ergebnis: -3.5" && echo "ERROR: Found a wrong output Division"
test "$(java TaschenRechner  12 mod 5)" != "Ergebnis: 2.0" && echo "ERROR: Found a wrong output Modulo"
test "$(java TaschenRechner 8 div 0)" != "Never divide through zero!" && echo "ERROR: Found a wrong output Division Zero"
test "$(java TaschenRechner 4 mult)" != "Ungültige Anzahl an Argumenten" && echo "ERROR: Found a wrong output NotEnoughArgs"
test "$(java TaschenRechner 4 mult 2 div 3)" != "Ungültige Anzahl an Argumenten" && echo "ERROR: Found a wrong output TooManyArgs"
test "$(java TaschenRechner 4.6 mod 99)" != "Modulo nur mit Ganzzahlen" && echo "ERROR: Found a wrong output Mod Kommazahl"
test "$(java TaschenRechner 4 sub -99)" != "Ergebnis: 103.0" && echo "ERROR: Found a wrong output SubNegative"
test "$(java TaschenRechner 4 div --3)" != "Eine der Zahlen stimmt nicht" && echo "ERROR: Found a wrong output DoubleNegative"
test "$(java TaschenRechner 4,6 add 2)" != "Eine der Zahlen stimmt nicht" && echo "ERROR: Found a wrong output KommaStattPunkt"
test "$(java TaschenRechner)" != "Ungültige Anzahl an Argumenten" && echo "ERROR: Found a wrong output KeineArgumente"
test "$(java TaschenRechner 4 mod 0)" != "Ergebnis: NaN" && echo "ERROR: Found a wrong output ModZero"

	echo Test complete.
