import java.util.Scanner;

public class Ordnungsrechner {
	public static void main (String[] args){
		int prim, element, ordnung;
		Scanner in = new Scanner(System.in);
		
		System.out.print("----Ordnung eines Elementes a in der Gruppe Z*p----\nPrimzahl p als Gruppengr��e: ");
		prim = in.nextInt();
		System.out.print("Zu pr�fendes Element a: ");
		element = in.nextInt();
		
		ordnung = bstOrdnung(element, prim);
		
		System.out.println("Die Ordnung von " + element + " in der Gruppe Z*" + prim +" ist " + ordnung + ".");
		
		in.close();
	}
	
	private static int bstOrdnung(int a, int p){
		double r1 = a, i = 1, r2 = a;
		while (r2 != 1){
			i++;
			r2 = r2*r1 % p;
		}
		return (int)i;
	}
}
