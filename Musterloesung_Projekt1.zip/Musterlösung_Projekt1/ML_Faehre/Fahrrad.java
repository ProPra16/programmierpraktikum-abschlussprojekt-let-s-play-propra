public class Fahrrad extends Fahrzeug {

	public Fahrrad(Person fahrer, double breite, double laenge, double gewicht){
		super(fahrer, breite, laenge, gewicht);
	}
	
}
