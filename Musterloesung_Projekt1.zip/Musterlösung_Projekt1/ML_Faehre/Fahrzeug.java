public abstract class Fahrzeug {

	// Attribute jedes Fahrzeugs
	private Person fahrer;
	private double breite;
	private double laenge;
	private double gewicht;
	private double gesamtgewicht;

	protected Fahrzeug(Person fahrer, double breite,
			double laenge, double gewicht){
		this.fahrer = fahrer;
		this.breite = breite;
		this.laenge = laenge;
		this.gewicht = gewicht;
	}
	
	public void berechneGewicht(){
		gesamtgewicht += gewicht + fahrer.getGewicht();
	}
	
	public double berechneFlaeche(){
		 double flaeche = 0.0;
		 flaeche = (breite*laenge)*1.5;
		 return flaeche;
	}
	
	public double getGesamtgewicht(){
		return gesamtgewicht;
	}
	
	public void setGesamtgewicht(double gesamtgewicht){
		this.gesamtgewicht = gesamtgewicht;
	}
}
