import java.util.ArrayList;

public class Pkw extends Fahrzeug {
	
	// spezielle Attribute eines Pkw
	private ArrayList<Person> beifahrer = new ArrayList<>();

	public Pkw(Person fahrer, double breite, double laenge, double gewicht){
		super(fahrer, breite, laenge, gewicht);
	}

	@Override
	public void berechneGewicht(){
		double gesamtgewicht;
	
		super.berechneGewicht();
		
		gesamtgewicht = getGesamtgewicht();
		
		for (int i = 0; i < beifahrer.size(); i++){
			if (beifahrer.get(i) != null){
				gesamtgewicht = gesamtgewicht + beifahrer.get(i).getGewicht();
			}
		}
		setGesamtgewicht(gesamtgewicht);
	}
	
	public void setBeifahrer(double gewicht){
		Person insasse = new Person(gewicht);
		beifahrer.add(insasse);
	}
}
