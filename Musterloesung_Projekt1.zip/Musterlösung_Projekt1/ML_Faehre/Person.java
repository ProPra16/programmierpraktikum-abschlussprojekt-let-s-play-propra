public class Person {
	// Attribut einer Person
	private double gewicht;

	public Person(double gewicht){
		this.gewicht = gewicht;
	}

	public double getGewicht() {
		return gewicht;
	}

}
