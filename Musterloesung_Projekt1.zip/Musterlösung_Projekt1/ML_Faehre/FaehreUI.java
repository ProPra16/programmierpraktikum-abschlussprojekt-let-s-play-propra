public class FaehreUI {

	public static void main (String[] args){
		
		Faehre faehre = new Faehre(750000,10000);
		int weiter = 1;
		
		while(weiter == 1){
			double gewichtf, laenge, breite, gewicht; 
			int beifahreranz;
			
			gewichtf = zufallszahl(40,120);
			Person fahrer = new Person(gewichtf);
			int typ =(int) Math.rint(zufallszahl(0,2));

			switch (typ){
			
			case 0: // PKW
				laenge = zufallszahl(3,7);
				breite = zufallszahl(2,4);
				gewicht = zufallszahl(1000,2800);
				
				Pkw pkw = new Pkw(fahrer, breite, laenge, gewicht);
				
				// Beifahrer erzeugen
				beifahreranz = (int) Math.rint(zufallszahl(0,3));
				for (int i = 0; i < beifahreranz; i++){
					gewichtf = zufallszahl(40,120);
					pkw.setBeifahrer(gewichtf);
				}
				
				pkw.berechneGewicht();
				weiter = faehre.aufladen(pkw);
				break;
			
			case 1: //Motorrad
				laenge = zufallszahl(1.5,4);
				breite = zufallszahl(1,3);
				gewicht = zufallszahl(150,400);
				
				Motorrad motorr = new Motorrad(fahrer, breite, laenge, gewicht);
				
				// Beifahrer erzeugen
				beifahreranz = (int) Math.rint(zufallszahl(0,2));
				for (int i = 0; i < beifahreranz; i++){
					gewichtf = zufallszahl(40,120);
					motorr.setBeifahrer(gewichtf);
				}
				
				motorr.berechneGewicht();
				weiter = faehre.aufladen(motorr);
				break;
				
			case 2: //Fahrrad
				laenge = zufallszahl(1,3);
				breite = zufallszahl(0.5,1.5);
				gewicht = zufallszahl(5,20);

				Fahrrad fahrr = new Fahrrad(fahrer, breite, laenge, gewicht);

				fahrr.berechneGewicht();
				weiter = faehre.aufladen(fahrr);
				break;
			}	
		};
		
		// Abfrage, an was die letzte Aufladung gescheitert ist
		if (weiter == 2){
			System.out.println("Die F�hre bietet nicht genug Platz, um ein weiteres Fahrzeug aufzunehmen.");
		} else if(weiter == 3){
			System.out.println("Die F�hre bietet nicht ausreichend Traglast, um ein weiteres Fahrzeug aufzunehmen.");
		} else if(weiter == 4){
			System.out.println("Die F�hre bietet weder genug Platz, noch ausreichend Traglast, um ein weiteres Fahrzeug aufzunehmen.");
		}
	}
	
	public static double zufallszahl(double min, double max){
		double zufall = Math.random() * (max - min) + min;

		zufall = zufall * 10;
		zufall = Math.round(zufall);
		zufall = zufall / 10;
		
		return zufall;
	}
	
}
