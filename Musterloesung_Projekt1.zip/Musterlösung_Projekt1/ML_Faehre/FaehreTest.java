import static org.junit.Assert.*;

import org.junit.Test;

public class FaehreTest {
	
	@Test
	public void maxGewichtUeberschritten() {
		Faehre test = new Faehre(10,1000);
		Person einePerson = new Person(75);
		Pkw einPkw = new Pkw(einePerson, 2, 5, 1500);
		einPkw.berechneGewicht();
		int expected = 3;
		assertEquals(expected, test.aufladen(einPkw));
	}
	
	@Test
	public void maxFlaecheUeberschritten() {
		Faehre test = new Faehre(10000,5);
		Person einePerson = new Person(75);
		Pkw einPkw = new Pkw(einePerson, 2, 5, 1500);
		einPkw.berechneFlaeche();
		int expected = 2;
		assertEquals(expected, test.aufladen(einPkw));
	}
	
	@Test
	public void maxGeundFlUeberschritten() {
		Faehre test = new Faehre(10,10);
		Person einePerson = new Person(75);
		Pkw einPkw = new Pkw(einePerson, 2, 5, 1500);
		einPkw.berechneGewicht();
		einPkw.berechneFlaeche();
		int expected = 4;
		assertEquals(expected, test.aufladen(einPkw));
	}
	
	@Test
	public void fehlerNachZweitemFahrzeug() {
		Faehre test = new Faehre(1600,10000);
		Person einePerson = new Person(75);
		Pkw einPkw = new Pkw(einePerson, 2, 5, 1500);
		Pkw nochEinPkw = new Pkw(einePerson, 2 , 5, 2100);
		einPkw.berechneGewicht();
		nochEinPkw.berechneGewicht();
		int expected = 3;
		test.aufladen(einPkw);
		assertEquals(expected, test.aufladen(nochEinPkw));
	}
	
	@Test
	public void aufladenErfolgreich() {
		Faehre test = new Faehre(10000,10000);
		Person einePerson = new Person(75);
		Pkw einPkw = new Pkw(einePerson, 2, 5, 1500);
		einPkw.berechneGewicht();
		int expected = 1;
		assertEquals(expected, test.aufladen(einPkw));
	}
	
	@Test
	public void eineinthalbfacheFl�chenSkalierung() {
		Person einePerson = new Person(75);
		Pkw einPkw = new Pkw(einePerson, 2, 5, 1500);
		double expected = (2*5)*1.5;
		assertTrue(expected == einPkw.berechneFlaeche());
	}
}
