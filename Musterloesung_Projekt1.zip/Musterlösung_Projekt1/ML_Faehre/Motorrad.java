import java.util.ArrayList;

public class Motorrad extends Fahrzeug {
	
	// spezielle Attribute eines Motorrads
	private ArrayList<Person> beifahrer = new ArrayList<>();
	
	// geerbter Konstruktor
	public Motorrad(Person fahrer, double breite, double laenge, double gewicht){
		super(fahrer, breite, laenge, gewicht);
	}
	
	// überschriebene Gewichtsberechnung
	@Override
	public void berechneGewicht(){
		double gesamtgewicht;
	
		super.berechneGewicht();
		
		gesamtgewicht = getGesamtgewicht();
		
		for (int i = 0; i < beifahrer.size(); i++){
			if (beifahrer.get(i) != null){
				gesamtgewicht = gesamtgewicht + beifahrer.get(i).getGewicht();
			}
		}
		setGesamtgewicht(gesamtgewicht);
	}
	
	// neuen Beifahrer erstellen und dem Motorrads zuweisen
	public void setBeifahrer(double gewicht){
		Person insasse = new Person(gewicht);
		beifahrer.add(insasse);
	}
}
	
