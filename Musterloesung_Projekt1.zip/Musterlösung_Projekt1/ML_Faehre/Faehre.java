import java.util.ArrayList;

public class Faehre {
	private double maxNutzGewicht = 0.0;
	private double maxNutzFlaeche = 0.0;
	private double restFlaeche = 0.0;
	private double restGewicht = 0.0;
	private int anzahlPkw;
	private int anzahlFahrr;
	private int anzahlMotorr;
	private ArrayList <Fahrzeug> aufgeladen = new ArrayList<>();

	public Faehre(double maxNutzGewicht, double maxNutzFlaeche){
		this.maxNutzGewicht = maxNutzGewicht;
		this.maxNutzFlaeche = maxNutzFlaeche;
		this.restFlaeche = maxNutzFlaeche;
		this.restGewicht = maxNutzGewicht;
	}
	
	public int aufladen (Fahrzeug fahrzeug){
		int status = 1;
		double fl, ge;
		String typ;
		
		fl = fahrzeug.berechneFlaeche();
		ge = fahrzeug.getGesamtgewicht();
		
		typ = fahrzeug.getClass().getName();
		
		if ((restFlaeche >= fl) && (restGewicht >= ge)){
			aufgeladen.add(fahrzeug);
			restFlaeche -= fl;
			restGewicht -= ge;
			
			switch (typ){
			case "Pkw":
				anzahlPkw++;
				break;
			case "Fahrrad":
				anzahlFahrr++;
				break;
			case "Motorrad":
				anzahlMotorr++;
				break;				
			}
			
			// Aufladen erfolgreich
			status = 1;

		} else if (restFlaeche < fl){
			if (restGewicht < ge){
				status = 4;
				gibLadung();
				gibRest();
				return status;
			}
			gibLadung();
			gibRest();
			status = 2;
		} else if (restGewicht < ge){
			gibLadung();
			gibRest();
			status = 3;
		}
		return status;
	}
	
	public void gibLadung(){
		System.out.println("Beladene Fahrzeuge: " + anzahlPkw + "x PKW / " + anzahlMotorr + "x Motorrad / "+ anzahlFahrr +"x Fahrrad");
	}
	
	public void gibRest(){
		System.out.println("Aktuelle Nutzflaeche: " + (int)(Math.rint(maxNutzFlaeche-restFlaeche)) + "m�\nAktuelles Nutzgewicht: " + (int)(Math.rint(maxNutzGewicht-restGewicht)) +"kg");
	}
}
