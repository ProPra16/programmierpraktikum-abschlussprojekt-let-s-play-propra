
import java.io.IOException;
/**
*/
public class TaschenRechner {
    public static void main(String[] args) throws IOException {
        double ANS = 0.0;
        double x = 0.0;
        double y = 0.0;
        String m;
        if (args.length == 3) {
            try {

                x = Double.parseDouble(args[0]);
            } catch (NumberFormatException nfe) {
                System.out.println("Eine der Zahlen stimmt nicht");
                return;
            }

            try {

                y = Double.parseDouble(args[2]);
            } catch (NumberFormatException nfe) {
                System.out.println("Eine der Zahlen stimmt nicht");
                return;
            }
            m = args[1];
            switch (m) {
                case "mult":
                    ANS = x * y;
                    System.out.println("Ergebnis: " + ANS);
                    break;
                case "add":
                    ANS = x + y;
                    System.out.println("Ergebnis: " + ANS);
                    break;
                case "div":
                    if (y == 0) {
                        System.out.println("Never divide through zero!");
                    } else {
                        ANS = x / y;
                        System.out.println("Ergebnis: " + ANS);
                    }
                    break;
                case "sub":
                    ANS = x - y;
                    System.out.println("Ergebnis: " + ANS);
                    break;
                case "mod":
                    if (x % 1 == 0) {
                        if (y % 1 == 0) {
                            ANS = x % y;
                            System.out.println("Ergebnis: " + ANS);
                        } else {
                            System.out.println("Modulo nur mit Ganzzahlen");
                            break;
                        }
                    } else {
                        System.out.println("Modulo nur mit Ganzzahlen");
                        break;
                    }

                    break;
                default:
                    System.out.println("Ungültige Rechenoperation");

            }
        } else {
            System.out.println("Ungültige Anzahl an Argumenten");
        }
    }
}

