
public interface Warmblueter {
    boolean brauchtKeineWaerme();



}
