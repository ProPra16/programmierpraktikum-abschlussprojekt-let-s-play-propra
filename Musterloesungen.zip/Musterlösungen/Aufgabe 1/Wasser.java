
public interface Wasser {
    boolean lebtInWasser();
}
