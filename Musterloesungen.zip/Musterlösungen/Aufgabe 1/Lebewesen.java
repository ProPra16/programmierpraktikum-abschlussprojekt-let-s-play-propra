

public class Lebewesen {
    private double Gewicht;
    private int Groesse;


        /**

         */
    public Lebewesen(double w,int h){
        this.Gewicht= w;
        this.Groesse=h;
        System.out.println(this.getGewicht());
        System.out.println(this.getGroesse());
    }


    public String getGewicht(){
        return ("Gewicht: "+Gewicht+"kg");
    }

    public String getGroesse() {
        return ("Größe: "+Groesse+"cm");
    }
}
