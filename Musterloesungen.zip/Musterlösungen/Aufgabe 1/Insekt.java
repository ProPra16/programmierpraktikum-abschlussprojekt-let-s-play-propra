
public class Insekt extends Lebewesen implements Wechselwarm,Flug{
    private boolean hatChitinpanzer;
    private boolean fluegel;
    private boolean flug;
    @Override public boolean brauchtWaerme(){
        return true;
    }
    @Override public boolean kannFliegen() {
        return flug;
    }
    @Override public boolean hatFluegel(){
        return fluegel;
    }
    /**
     */
    public Insekt(double gewicht, int groesse,boolean chitin, boolean fluegel1, boolean flug1) {
        super(gewicht, groesse);
        this.hatChitinpanzer=true;
        this.fluegel=fluegel1;
        this.flug=flug1;
        System.out.println("Tierart: Insekt");
        System.out.println(this.getFlug());
        System.out.println(this.getFluegel());
        System.out.println(this.getChitin());
        System.out.println(this.getIstWarm());

    }
    public String getFlug(){
        if (this.kannFliegen()){
            return "kann Fliegen";
        }
        else{
            return "ist flugunfähig";
        }
    }
    public String getIstWarm(){
        if (this.brauchtWaerme()){
            return "Kaltblüter";
        }
        else{
            return "Warmblüter";
        }
    }
    public String getChitin() {
        if (this.hatChitinpanzer) {
            return "hat einen Chitinpanzer";
        } else {
            return "hat keinen Chitinpanzer";
        }
    }
    public String getFluegel() {
        if (this.hatFluegel()) {
            return "hat Flügel";
        } else {
            return "hat keine Flügel";
        }
    }
}
