
public class Saeugetier extends Lebewesen implements Warmblueter{
    private boolean hatFell;
    private boolean Warmblueter;
    @Override public boolean brauchtKeineWaerme(){
        return true;
    }
    /**
     */
    public Saeugetier(double gewicht, int groesse,boolean fell, boolean warmblut) {
        super(gewicht,groesse);
        this.hatFell=fell;
        this.Warmblueter=warmblut;
        System.out.println("Tierart: Säugetier");
        System.out.println(this.getFell());
        System.out.println(this.getIstWarm());

    }
    public String getIstWarm() {
        if (this.brauchtKeineWaerme()) {
            return "Warmblüter";
        } else {
            return "Kaltblüter";
        }
    }
    public String getFell() {
        if (this.hatFell) {
            return "hat Fell";
        } else {
            return "hat kein Fell";
        }
    }
}
