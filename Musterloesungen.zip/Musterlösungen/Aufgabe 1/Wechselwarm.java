
public interface Wechselwarm {
    boolean brauchtWaerme();


}
