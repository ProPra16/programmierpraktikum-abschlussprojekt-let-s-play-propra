
public class Vogel extends Lebewesen implements Flug,Warmblueter{
    private boolean hatFedern;
    private boolean fluegel;
    private boolean flug;
    @Override public boolean kannFliegen() {
        return flug;
    }
    @Override public boolean hatFluegel(){
        return fluegel;
    }
    @Override public boolean brauchtKeineWaerme(){
        return true;
    }
    public Vogel(double gewicht, int groesse,boolean federn, boolean fluegel1, boolean flug1) {
        super(gewicht,groesse);
        this.hatFedern=federn;
        this.fluegel=fluegel1;
        this.flug=flug1;
        System.out.println("Tierart: Vogel");
        System.out.println(this.getFlug());
        System.out.println(this.getFedern());
        System.out.println(this.getFluegel());
        System.out.println(this.getIstWarm());
    }
    public String getFlug(){
        if (this.kannFliegen()){
            return "kann Fliegen";
        }
        else{
            return "ist flugunfähig";
        }
    }
    public String getFluegel() {
        if (this.hatFluegel()) {
            return "hat Flügel";
        } else {
            return "hat keine Flügel";
        }
    }
    public String getFedern(){
        if (this.hatFedern){
            return "hat Federn";
        }
        else{
            return "hat keine Federn";
        }
    }
    public String getIstWarm(){
        if (this.brauchtKeineWaerme()){
            return "Warmblüter";
        }
        else{
            return "Kaltblüter";
        }
    }
}
