
public interface Flug {
    boolean kannFliegen();
    boolean hatFluegel();
}

