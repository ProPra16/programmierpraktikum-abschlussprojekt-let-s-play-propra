	#!/bin/bash
	echo Compile the source ...
	javac AnimalStats.java
	
	echo Testing ...
		test "$(java AnimalStats Spatz)" != "Spatz Eintrag:
Gewicht: 0.8kg
Größe: 15cm
Tierart: Vogel
kann Fliegen
hat Federn
hat Flügel
Warmblüter" && echo "ERROR: Found a wrong output at Spatz"

	test "$(java AnimalStats Hund)" != "Hund Eintrag:
Gewicht: 20.0kg
Größe: 100cm
Tierart: Säugetier
hat Fell
Warmblüter" && echo "ERROR: Found a wrong output at Hund"


	test "$(java AnimalStats Dorsch)" != "Dorsch Eintrag:
Gewicht: 14.0kg
Größe: 140cm
Tierart: Fisch
lebt in Gewässern
legt Eier
hat Schuppen
Kaltblüter" && echo "ERROR: Found a wrong output at Dorsch"

test "$(java AnimalStats Biene)" != "Biene Eintrag:
Gewicht: 0.05kg
Größe: 3cm
Tierart: Insekt
kann Fliegen
hat Flügel
hat einen Chitinpanzer
Kaltblüter" && echo "ERROR: Found a wrong output at Biene"
test "$(java AnimalStats Echse)" != "Echse Eintrag:
Gewicht: 3.0kg
Größe: 60cm
Tierart: Reptil
legt Eier
hat Hornschuppen
Kaltblüter" && echo "ERROR: Found a wrong output at Echse"
test "$(java AnimalStats)" != "Ungültiges oder fehlendes Startargument" && echo "ERROR: Found a wrong output at no Startargument"
test "$(java AnimalStats Babdi2)" != "Ungültiges oder fehlendes Startargument" && echo "ERROR: Found a wrong output at wrong Startargument"

	echo Test complete.
