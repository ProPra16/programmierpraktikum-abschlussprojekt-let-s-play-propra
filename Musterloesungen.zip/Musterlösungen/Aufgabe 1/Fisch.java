
public class Fisch extends Lebewesen implements Wasser,Wechselwarm {
    private boolean imWasser;
    private boolean hatSchuppen;
    private boolean legtEier;
    private boolean Wechselwarm;
    @Override public boolean lebtInWasser(){
        return imWasser;
    }
    @Override public boolean brauchtWaerme(){
        return Wechselwarm;
    }

    public Fisch(double gewicht, int groesse, boolean schwimm, boolean Schuppen ,boolean Eierlegend, boolean brauchWaerme){
        super(gewicht, groesse);
        this.hatSchuppen=Schuppen;
        this.Wechselwarm=brauchWaerme;
        this.legtEier=Eierlegend;
        this.imWasser=schwimm;
        System.out.println("Tierart: Fisch");
        System.out.println(this.getImWasser());
        System.out.println(this.getLegtEier());

        System.out.println(this.getSchuppen());
        System.out.println(this.getIstWarm());

    }
    public String getIstWarm() {
        if (this.brauchtWaerme()) {
            return "Kaltblüter";
        } else {
            return "Warmblüter";
        }
    }
    public String getImWasser() {
        if (this.lebtInWasser()) {
            return "lebt in Gewässern";
        } else {
            return "lebt an Land";
        }
    }
    public String getLegtEier(){
        if (this.legtEier){
            return "legt Eier";
        }
        else{
            return "Lebendgebärend";
        }
    }
    public String getSchuppen() {
        if (this.hatSchuppen) {
            return "hat Schuppen";
        } else {
            return "hat keine Schuppen";
        }
    }
}
