
public class Reptil extends Lebewesen implements Wechselwarm{

    private boolean legtEier;
    private boolean hatHornschuppen;
    private boolean Wechselwarm;

    @Override public boolean brauchtWaerme(){
        return Wechselwarm;
    }
    /**
     */
    public Reptil(double gewicht, int groesse,boolean Eierlegend, boolean Hornschuppen , boolean brauchWaerme){
        super(gewicht, groesse);
        this.hatHornschuppen=Hornschuppen;
        this.Wechselwarm=brauchWaerme;
        this.legtEier=Eierlegend;
        System.out.println("Tierart: Reptil");
        System.out.println(this.getLegtEier());
        System.out.println(this.getHornschuppen());
        System.out.println(this.getIstWarm());

    }
    public String getIstWarm() {
        if (this.brauchtWaerme()) {
            return "Kaltblüter";
        } else {
            return "Warmblüter";
        }
    }
    public String getLegtEier(){
        if (this.legtEier){
            return "legt Eier";
        }
        else{
            return "Lebendgebärend";
        }
    }
    public String getHornschuppen() {
        if (this.hatHornschuppen) {
            return "hat Hornschuppen";
        } else {
            return "hat keine Hornschuppen";
        }
    }
}
