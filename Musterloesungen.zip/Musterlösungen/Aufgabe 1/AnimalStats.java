import java.io.*;

/**
 * Print stats of animals
 *
 */
public class AnimalStats {
    public static void main(String[]args){
    if(args.length==1) {
        String b = args[0];
        switch (b) {
            case "Spatz":
                System.out.println("Spatz Eintrag:");
                Vogel Spatz = new Vogel(0.8, 15, true, true, true);

                break;
            case "Biene":
                System.out.println("Biene Eintrag:");
                Insekt Biene = new Insekt(0.05, 3, true, true, true);

                break;
            case "Echse":
                System.out.println("Echse Eintrag:");
                Reptil Echse = new Reptil(3, 60, true, true, true);

                break;
            case "Dorsch":
                System.out.println("Dorsch Eintrag:");
                Fisch Dorsch = new Fisch(14, 140, true, true, true, true);

                break;
            case "Hund":
                System.out.println("Hund Eintrag:");
                Saeugetier Hund = new Saeugetier(20, 100, true, true);

                break;
            default:
                System.out.println("Ungültiges oder fehlendes Startargument");
        }
    }
        else {
        System.out.println("Ungültiges oder fehlendes Startargument");
    }
    }
}
